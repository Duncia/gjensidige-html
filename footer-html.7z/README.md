# Test task

## Figma to code

- HTML<br>
- CSS (SASS)
- node-sass, nodemon, uglify-css NPM packages
- Fonts converted to woff/woff2
